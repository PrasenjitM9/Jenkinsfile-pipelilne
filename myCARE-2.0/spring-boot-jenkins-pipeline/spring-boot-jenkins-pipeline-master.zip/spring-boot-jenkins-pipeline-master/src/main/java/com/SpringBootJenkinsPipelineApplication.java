package com;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringBootJenkinsPipelineApplication {

    public static void main(String[] args) {
        SpringApplication.run(SpringBootJenkinsPipelineApplication.class, args);
    }

}
