# spring-boot-jenkins-pipeline
Spring Boot Jenkins Pipeline Example
